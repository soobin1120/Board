/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module KsbBoard {
}