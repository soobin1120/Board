package com.ksb.data;

import java.util.ArrayList;

public class Data {
	public static ArrayList<Post>posts=new ArrayList<>();
	public static void loadData() {
		posts=new ArrayList<>();
	}
	

}
