package com.ksb.data;

import java.time.LocalDate;

import com.ksb.util.Cw;

public class Post {
	public static int no=0;
	public int instanceNo=0;
	public String title;
	public String content;
	public String writer;
	public int hit;
	public String date;
	public Post(String title, String content,String writer,int hit) {
		no=no+1;
		instanceNo=no;
		this.title=title;
		this.content=content;
		this.writer=writer;
		this.hit=hit;
		LocalDate now=LocalDate.now();
		date= now.toString();
	}
	public void infoForList() {
		Cw.w("작성글 번호"+instanceNo);
		Cw.w();
		Cw.w("글제목"+title);
		Cw.w();
		Cw.w("작성자"+writer);
		Cw.w();
		Cw.w("조회수"+ hit);
		Cw.w();
		Cw.wn("작성일"+date);
		
	}
	public void infoForRead() {
		Cw.w("작성글 번호"+instanceNo);
		Cw.w();
		Cw.w("글제목"+title);
		Cw.w();
		Cw.w("작성자"+writer);
		Cw.w();
		Cw.wn("조회수"+ hit);
		Cw.wn("내용"+content);
		Cw.wn("작성일"+date);
	}

}
