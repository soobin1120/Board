package com.ksb.display;

import com.ksb.board.Board;
import com.ksb.util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(15);
		Cw.w(Board.TITLE);
		Cw.space(15);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}

	public static void mainMenu() {
		Cw.dot();
		Cw.w("[1.작성글 리스트/2.작성글 읽기/3.글 작성하기/4.작성글 삭제/5.작성글 수정]");
		Cw.dot();
		Cw.wn();

		}
}