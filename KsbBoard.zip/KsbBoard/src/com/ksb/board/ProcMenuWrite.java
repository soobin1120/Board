package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.data.Post;
import com.ksb.util.Ci;
import com.ksb.util.Cw;

public class ProcMenuWrite {
	public static void run() {
		Cw.wn("글 작성하기");
		String title;
		while(true) {
			title=Ci.rl("글제목");
			if(title.length()>0) {
				break;
			}else {
				Cw.wn("잘못된입력입니다.");
			}
		}
		String content;
		while(true) {
			content=Ci.rl("글 내용");
			if(content.length()>0) {
				break;
			}else {
				Cw.wn("잘못된입력입니다.");
			}
		}
		String writer;
		while(true) {
			writer=Ci.rl("작성자");
			if(writer.length()>0) {
				break;
			}else {
				Cw.wn("잘못된입력입니다.");
			}
		}
		
		Post p = new Post(title,content,writer,0);
		Data.posts.add(p);
		Cw.wn("작성완료");
		
	}

}
