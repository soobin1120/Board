package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.data.Post;
import com.ksb.util.Ci;
import com.ksb.util.Cw;

public class ProcMenuUpdate {
	public static void run() {
		Cw.wn("작성글 수정");
		String cmd=Ci.rl("수정할 글 번호");
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				String content=Ci.rl("수정할 글 내용");
				p.content=content;
				Cw.wn("수정이 완료되었습니다.");
				
			}
		}
	}

}
