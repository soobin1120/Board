package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.display.Disp;

public class Board {
	
	public static final String VERSION= "V.Final";
	public static final String TITLE="자유 게시판("+VERSION+ ")feat.sb.Kim";
	
	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}

}
