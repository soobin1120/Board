package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.data.Post;
import com.ksb.util.Ci;
import com.ksb.util.Cw;

public class ProcMenuRead {
	public static void run() {
	Cw.wn("글읽기입니다.");
	String cmd=Ci.rl("읽으실 글번호");
	for(Post p: Data.posts) {
		if(cmd.equals(p.instanceNo+"")) {
			p.infoForRead();
		}
	}
	}

}
