package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.data.Post;
import com.ksb.util.Cw;

public class ProcMenuList {
	public static void run() {
	Cw.wn("작성글 리스트입니다.");
	for(Post p:Data.posts) {
		p.infoForList();
	}

}
}
