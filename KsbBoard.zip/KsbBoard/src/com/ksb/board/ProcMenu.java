package com.ksb.board;

import com.ksb.display.Disp;
import com.ksb.util.Ci;
import com.ksb.util.Cw;

public class ProcMenu {
	static void run() {
		Disp.mainMenu();
		loop:
			while(true) {
				String cmd=Ci.r("선택");
				switch(cmd) {
				case "1":
					ProcMenuList.run();
					break;
				case "2":
					ProcMenuRead.run();
					break;
				case "3":
					ProcMenuWrite.run();
					break;
				case "4":
					ProcMenuDel.run();
					break;
				case "5":
					ProcMenuUpdate.run();
					break;
				case "x":
					Cw.wn("프로그램 종료");
					break loop;
				default :
					Cw.wn("잘못된 입력입니다.");
					break;
				}
			}
		
	}

}
