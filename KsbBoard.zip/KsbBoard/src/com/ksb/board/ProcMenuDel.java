package com.ksb.board;

import com.ksb.data.Data;
import com.ksb.util.Ci;
import com.ksb.util.Cw;

public class ProcMenuDel {
	
	public static void run() {
		Cw.wn("작성글 삭제");
		String cmd=Ci.rl("삭제할 글 번호");
		int tempSearchIndex=0;
		for(int i=0;i<Data.posts.size();i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex=i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		Cw.wn("전체 작성글 수:"+Data.posts.size());
	}

}
